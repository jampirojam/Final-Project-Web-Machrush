<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Username or E-mailPasswordOnly fill in _26284d</name>
   <tag></tag>
   <elementGuidId>e08e53b6-539f-480f-a523-47bd204bf4cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//article[@id='post-313']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.entry-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b76d4ad8-e6c2-4967-b377-ef257ce8d61e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>entry-content</value>
      <webElementGuid>365c5b5d-c727-4c82-833b-e0866de0aca5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
		



	

		

			Username or E-mail

						Password

								
	
	
		Only fill in if you are not human
		
	

	
	

		

			
				
					
						
						
						 Keep me signed in
					
				
			

						
		
			
				
			

		
		

	

	
	
		
			Forgot your password?		
	

	
		

	


.um-298.um {
	max-width: 450px;
}









	</value>
      <webElementGuid>9d38938a-7a16-4e08-81cc-53013fb3d76e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-313&quot;)/div[@class=&quot;entry-content&quot;]</value>
      <webElementGuid>19453b62-af3b-4988-996b-6def53678a50</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-313']/div</value>
      <webElementGuid>e9c144ca-dd98-41a8-937b-dd55c6f39927</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[4]/following::div[1]</value>
      <webElementGuid>accc83f4-2db1-4bc6-b0ca-d9515e8fe2ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::div[5]</value>
      <webElementGuid>c50e73cf-1f63-4cf9-b17e-61537a8bad13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//article/div</value>
      <webElementGuid>da157a3a-99c0-4a66-9674-01969d03811a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
		



	

		

			Username or E-mail

						Password

								
	
	
		Only fill in if you are not human
		
	

	
	

		

			
				
					
						
						
						 Keep me signed in
					
				
			

						
		
			
				
			

		
		

	

	
	
		
			Forgot your password?		
	

	
		

	


.um-298.um {
	max-width: 450px;
}









	' or . = '
		



	

		

			Username or E-mail

						Password

								
	
	
		Only fill in if you are not human
		
	

	
	

		

			
				
					
						
						
						 Keep me signed in
					
				
			

						
		
			
				
			

		
		

	

	
	
		
			Forgot your password?		
	

	
		

	


.um-298.um {
	max-width: 450px;
}









	')]</value>
      <webElementGuid>8d1703fe-5de2-451e-8830-2b94bd9c9ba9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
