<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_UsernameThe username you entered is inco_fe26ce</name>
   <tag></tag>
   <elementGuidId>1392a3e8-3685-4f16-87cb-051b48cb9562</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//article[@id='post-301']/div/figure/table/tbody/tr/td</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>87a27c7d-46aa-4f67-aedf-8e0ffa7ca3a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>


	

		

			Username

						The username you entered is incorrectE-mail Address

						The email you entered is incorrectPhone Number

						Password

						Your password must contain at least one lowercase letter, one capital letter and one numberConfirm PasswordAddress

								
	
	
		Only fill in if you are not human
		
	

	
	

		
			
				
			

		
		

	

			
		

	


.um-297.um {
	max-width: 450px;
}
</value>
      <webElementGuid>74c49b73-9620-4a16-812d-4993a59839b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-301&quot;)/div[@class=&quot;entry-content&quot;]/figure[@class=&quot;wp-block-table&quot;]/table[1]/tbody[1]/tr[1]/td[1]</value>
      <webElementGuid>e0ee2a0d-a4a8-4027-8919-5cbe926c9e3c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-301']/div/figure/table/tbody/tr/td</value>
      <webElementGuid>62d9bb36-73b0-40a8-87e2-1eabdc99aaa5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register Now'])[4]/following::td[1]</value>
      <webElementGuid>251d7ba6-52b7-4c28-9193-e23ce432b8f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::td[1]</value>
      <webElementGuid>cf3f5418-dbdf-4d2d-8fe8-fab89a524e07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td</value>
      <webElementGuid>db4ffa6d-e51b-4547-885f-34fc8c35a621</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = '


	

		

			Username

						The username you entered is incorrectE-mail Address

						The email you entered is incorrectPhone Number

						Password

						Your password must contain at least one lowercase letter, one capital letter and one numberConfirm PasswordAddress

								
	
	
		Only fill in if you are not human
		
	

	
	

		
			
				
			

		
		

	

			
		

	


.um-297.um {
	max-width: 450px;
}
' or . = '


	

		

			Username

						The username you entered is incorrectE-mail Address

						The email you entered is incorrectPhone Number

						Password

						Your password must contain at least one lowercase letter, one capital letter and one numberConfirm PasswordAddress

								
	
	
		Only fill in if you are not human
		
	

	
	

		
			
				
			

		
		

	

			
		

	


.um-297.um {
	max-width: 450px;
}
')]</value>
      <webElementGuid>fdc3551c-1bbd-4e34-9a2e-73ba29b065bc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
