<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_PasswordYour password must contain at l_f495ce</name>
   <tag></tag>
   <elementGuidId>6a2c758a-ae78-4d54-aa89-f5a0f6c05620</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='um_field_297_user_password']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#um_field_297_user_password</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>fa5f4b1a-fa84-411a-a480-1ff142513074</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>um_field_297_user_password</value>
      <webElementGuid>3dc20c14-bfa8-4280-93f7-cb4144a33710</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>um-field um-field-password  um-field-user_password um-field-password um-field-type_password</value>
      <webElementGuid>10df1d97-4fa4-473d-9ebd-8af5a5718ac4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-key</name>
      <type>Main</type>
      <value>user_password</value>
      <webElementGuid>14a7c8ce-c07a-4459-afbc-9b0a76b60bd4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Password

						Your password must contain at least one lowercase letter, one capital letter and one number</value>
      <webElementGuid>e0e6ff26-e2d5-45ae-a761-b66868741d77</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;um_field_297_user_password&quot;)</value>
      <webElementGuid>941bef44-643f-4e00-99b9-254fdc555671</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='um_field_297_user_password']</value>
      <webElementGuid>91a4b8a8-16a5-43ca-93a5-caea6f88ce98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-301']/div/figure/table/tbody/tr/td/div/div/form/div/div/div[4]</value>
      <webElementGuid>33b242a1-21d0-4886-8ef5-0e47bf21ad09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Phone Number'])[1]/following::div[3]</value>
      <webElementGuid>2a11d195-3263-4045-8974-0528d6a855b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The email you entered is incorrect'])[1]/following::div[5]</value>
      <webElementGuid>ebd53ea1-d85c-4d04-ae7d-7098318edc77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[4]</value>
      <webElementGuid>ffbcfb53-7235-4041-91c8-c243278e4498</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'um_field_297_user_password' and (text() = 'Password

						Your password must contain at least one lowercase letter, one capital letter and one number' or . = 'Password

						Your password must contain at least one lowercase letter, one capital letter and one number')]</value>
      <webElementGuid>41fb6610-5a7c-4ce5-ab46-a67b78b272e3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
