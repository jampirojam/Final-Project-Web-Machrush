<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_About Us</name>
   <tag></tag>
   <elementGuidId>1bfaa73c-91c8-4e2a-b3b6-2a5079e52960</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='menu-item-265']/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#menu-item-265 > a > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e3062b90-d063-4d42-b5bf-27e4aeaa1123</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>About Us</value>
      <webElementGuid>3b4b7b8a-4705-44dc-80d3-56bbac2f7dae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menu-item-265&quot;)/a[1]/span[1]</value>
      <webElementGuid>671ddd78-1077-4de1-b501-5512eb5a4185</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='menu-item-265']/a/span</value>
      <webElementGuid>236506ad-2b88-4cb2-b19e-2b6b5ff73900</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shop'])[1]/following::span[1]</value>
      <webElementGuid>3889dd39-4f5e-41ff-b57d-ababf6b4265f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::span[2]</value>
      <webElementGuid>c1d42f62-65d4-4cf3-90aa-542d4dd086ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register Now'])[1]/preceding::span[1]</value>
      <webElementGuid>33886d44-ec60-4faf-addd-3442c7727328</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/preceding::span[2]</value>
      <webElementGuid>e522e24b-f1a3-43e7-b821-69d211592929</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='About Us']/parent::*</value>
      <webElementGuid>15816745-aaf4-4b8d-9ad5-fa8899baf193</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/a/span</value>
      <webElementGuid>768d72b8-9fd4-4122-867a-6d1d8d3fc27c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'About Us' or . = 'About Us')]</value>
      <webElementGuid>06cc36a8-26c9-4c9f-99f1-5051dedb51fe</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
