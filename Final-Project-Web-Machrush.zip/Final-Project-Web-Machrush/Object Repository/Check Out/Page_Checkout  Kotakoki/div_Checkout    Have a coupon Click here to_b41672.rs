<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Checkout    Have a coupon Click here to_b41672</name>
   <tag></tag>
   <elementGuidId>f3928c47-5a85-4218-b9b6-77db304bfe99</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.site-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>1f6de82a-6aac-455a-a4f5-b6f28735b5d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>site-content</value>
      <webElementGuid>29beaf19-3d8a-4468-8657-71c394759bea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

				

	

    
        Checkout    


	
		
	
	
		Have a coupon? Click here to enter your code	




	If you have a coupon code, please apply it below.

	
		
	

	
		Apply coupon
	

	




	
		
		
			
				
	
		Billing details

	
	
	
			First name *Last name *Company name (optional)Country / Region *Select a country / region…AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntarcticaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelarusBelauBelgiumBelizeBeninBermudaBhutanBoliviaBonaire, Saint Eustatius and SabaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo (Brazzaville)Congo (Kinshasa)Cook IslandsCosta RicaCroatiaCubaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEswatiniEthiopiaFalkland IslandsFaroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHondurasHong KongHungaryIcelandIndiaIndonesiaIranIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesiaMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmarNamibiaNauruNepalNetherlandsNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorth KoreaNorth MacedoniaNorthern Mariana IslandsNorwayOmanPakistanPalestinian TerritoryPanamaPapua New GuineaParaguayPeruPhilippinesPitcairnPolandPortugalPuerto RicoQatarReunionRomaniaRussiaRwandaSão Tomé and PríncipeSaint BarthélemySaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (Dutch part)Saint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia/Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwedenSwitzerlandSyriaTaiwanTajikistanTanzaniaThailandTimor-LesteTogoTokelauTongaTrinidad and TobagoTunisiaTurkeyTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited Kingdom (UK)United States (US)United States (US) Minor Outlying IslandsUruguayUzbekistanVanuatuVaticanVenezuelaVietnamVirgin Islands (British)Virgin Islands (US)Wallis and FutunaWestern SaharaYemenZambiaZimbabweIndonesia&lt;button type=&quot;submit&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update country / region&quot;>Update country / region&lt;/button>Street address *Apartment, suite, unit, etc. (optional)Town / City *Province *Select an option…Daerah Istimewa AcehSumatera UtaraSumatera BaratRiauKepulauan RiauJambiSumatera SelatanBangka BelitungBengkuluLampungDKI JakartaJawa BaratBantenJawa TengahJawa TimurDaerah Istimewa YogyakartaBaliNusa Tenggara BaratNusa Tenggara TimurKalimantan BaratKalimantan TengahKalimantan TimurKalimantan SelatanKalimantan UtaraSulawesi UtaraSulawesi TengahSulawesi TenggaraSulawesi BaratSulawesi SelatanGorontaloMalukuMaluku UtaraPapuaPapua BaratBantenPostcode / ZIP *Phone *Email address *

	

			

			
				
	

	
	
		
			Additional information

		
		
							Order notes (optional)					

	
	
			
		

		
		
		
	Your order
	
	
	
		
	
		
			Product
			Subtotal
		
	
	
						
					
						Album 						 × 1											
					
						Rp15.000					
				
								
					
						Beanie with Logo 						 × 1											
					
						Rp20.000					
				
								
					
						Cap 						 × 1											
					
						Rp16.000					
				
					
	

		
			Subtotal
			Rp51.000
		

		
		
		
		
		
		
			Total
			Rp51.000 
		

		
	



			
			
	

	
		Bank Transfer - BCA 	
			
			Bayar pesanan dengan transfer bank BCA dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BNI 	
			
			Bayar pesanan dengan transfer bank BNI dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BRI 	
			
			Bayar pesanan dengan transfer bank BRI dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BSI 	
			
			Bayar pesanan dengan transfer bank BSI dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BJB 	
			
			Bayar pesanan dengan transfer bank BJB dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - Mandiri 	
			
			Bayar pesanan dengan transfer bank Mandiri dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - Permata 	
			
			Bayar pesanan dengan transfer bank Permata dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bayar di Alfamart Group 	
			
			Bayar pesanan dengan membayar di Alfa group (Alfamart, Alfamidi &amp; Dan+Dan) melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bayar di Indomaret 	
			
			Bayar pesanan dengan membayar di Indomaret, Indogrosir, Superindo, atau i.saku melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		ShopeePay 	
			
			Bayar pesanan dengan akun ShopeePay anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		OVO 	
			
			Bayar dengan OVO Anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		DANA 	
			
			Bayar dengan DANA Anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		LinkAja 	
			
			Bayar pesanan dengan akun LINKAJA anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Direct Debit BRI 	
			
			Bayar pesanan dengan akun Direct Debit BRI anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		QRIS 	
			
			Bayar pesanan dengan akun QRIS anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Kredivo 	
			
			Bayar pesanan dengan membayar menggunakan kredivo melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		UangMe 	
			
			Bayar pesanan dengan akun Uangme anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Credit Card (Xendit) 	
			
			Pay with your credit card via Xendit.TEST MODE. Try card &quot;4000000000000002&quot; with any CVN and future expiration date, or see Xendit Docs for more test cases.
		
	
		
		
		
			Since your browser does not support JavaScript, or it is disabled, please ensure you click the &lt;em>Update Totals&lt;/em> button before placing your order. You may be charged more than the amount stated above if you fail to do so.			&lt;br/>&lt;button type=&quot;submit&quot; class=&quot;button alt&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update totals&quot;>Update totals&lt;/button>
		

			
		
			
	
		Dengan menggunakan metode pembayaran ini, anda setuju bahwa semua data yang berhubungan dengan order anda akan diproses oleh saluran pembayaran.
		Place order
		
			


	

	



	
	


			</value>
      <webElementGuid>c1704ad2-777b-4489-bb8f-e7c05871052a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js_active vc_desktop vc_transform vc_transform&quot;]/body[@class=&quot;page-template-default page page-id-54 logged-in wp-embed-responsive theme-the-hanger woocommerce-checkout woocommerce-page woocommerce-js wpb-js-composer js-comp-ver-6.7.0 vc_responsive site-main-font header-layout-full content-layout-full  footer-layout-boxed&quot;]/div[@class=&quot;site-wrapper&quot;]/div[@class=&quot;site-content-wrapper&quot;]/div[@class=&quot;row small-collapse&quot;]/div[@class=&quot;small-12 columns&quot;]/div[@class=&quot;site-content&quot;]</value>
      <webElementGuid>4d1e8da4-5839-4502-9616-1fbf67ea3ec1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::div[4]</value>
      <webElementGuid>13f41732-6237-43de-bc35-2fe1e793c69f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search for:'])[1]/following::div[4]</value>
      <webElementGuid>f616cc9e-a371-4960-b828-df8b29c3b19f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div</value>
      <webElementGuid>70f20d4e-56b8-426e-bb37-e72bf04b20b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

				

	

    
        Checkout    


	
		
	
	
		Have a coupon? Click here to enter your code	




	If you have a coupon code, please apply it below.

	
		
	

	
		Apply coupon
	

	




	
		
		
			
				
	
		Billing details

	
	
	
			First name *Last name *Company name (optional)Country / Region *Select a country / region…AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntarcticaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelarusBelauBelgiumBelizeBeninBermudaBhutanBoliviaBonaire, Saint Eustatius and SabaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo (Brazzaville)Congo (Kinshasa)Cook IslandsCosta RicaCroatiaCubaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEswatiniEthiopiaFalkland IslandsFaroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHondurasHong KongHungaryIcelandIndiaIndonesiaIranIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesiaMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmarNamibiaNauruNepalNetherlandsNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorth KoreaNorth MacedoniaNorthern Mariana IslandsNorwayOmanPakistanPalestinian TerritoryPanamaPapua New GuineaParaguayPeruPhilippinesPitcairnPolandPortugalPuerto RicoQatarReunionRomaniaRussiaRwandaSão Tomé and PríncipeSaint BarthélemySaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (Dutch part)Saint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia/Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwedenSwitzerlandSyriaTaiwanTajikistanTanzaniaThailandTimor-LesteTogoTokelauTongaTrinidad and TobagoTunisiaTurkeyTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited Kingdom (UK)United States (US)United States (US) Minor Outlying IslandsUruguayUzbekistanVanuatuVaticanVenezuelaVietnamVirgin Islands (British)Virgin Islands (US)Wallis and FutunaWestern SaharaYemenZambiaZimbabweIndonesia&lt;button type=&quot;submit&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update country / region&quot;>Update country / region&lt;/button>Street address *Apartment, suite, unit, etc. (optional)Town / City *Province *Select an option…Daerah Istimewa AcehSumatera UtaraSumatera BaratRiauKepulauan RiauJambiSumatera SelatanBangka BelitungBengkuluLampungDKI JakartaJawa BaratBantenJawa TengahJawa TimurDaerah Istimewa YogyakartaBaliNusa Tenggara BaratNusa Tenggara TimurKalimantan BaratKalimantan TengahKalimantan TimurKalimantan SelatanKalimantan UtaraSulawesi UtaraSulawesi TengahSulawesi TenggaraSulawesi BaratSulawesi SelatanGorontaloMalukuMaluku UtaraPapuaPapua BaratBantenPostcode / ZIP *Phone *Email address *

	

			

			
				
	

	
	
		
			Additional information

		
		
							Order notes (optional)					

	
	
			
		

		
		
		
	Your order
	
	
	
		
	
		
			Product
			Subtotal
		
	
	
						
					
						Album 						 × 1											
					
						Rp15.000					
				
								
					
						Beanie with Logo 						 × 1											
					
						Rp20.000					
				
								
					
						Cap 						 × 1											
					
						Rp16.000					
				
					
	

		
			Subtotal
			Rp51.000
		

		
		
		
		
		
		
			Total
			Rp51.000 
		

		
	



			
			
	

	
		Bank Transfer - BCA 	
			
			Bayar pesanan dengan transfer bank BCA dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BNI 	
			
			Bayar pesanan dengan transfer bank BNI dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BRI 	
			
			Bayar pesanan dengan transfer bank BRI dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BSI 	
			
			Bayar pesanan dengan transfer bank BSI dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BJB 	
			
			Bayar pesanan dengan transfer bank BJB dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - Mandiri 	
			
			Bayar pesanan dengan transfer bank Mandiri dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - Permata 	
			
			Bayar pesanan dengan transfer bank Permata dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bayar di Alfamart Group 	
			
			Bayar pesanan dengan membayar di Alfa group (Alfamart, Alfamidi &amp; Dan+Dan) melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bayar di Indomaret 	
			
			Bayar pesanan dengan membayar di Indomaret, Indogrosir, Superindo, atau i.saku melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		ShopeePay 	
			
			Bayar pesanan dengan akun ShopeePay anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		OVO 	
			
			Bayar dengan OVO Anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		DANA 	
			
			Bayar dengan DANA Anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		LinkAja 	
			
			Bayar pesanan dengan akun LINKAJA anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Direct Debit BRI 	
			
			Bayar pesanan dengan akun Direct Debit BRI anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		QRIS 	
			
			Bayar pesanan dengan akun QRIS anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Kredivo 	
			
			Bayar pesanan dengan membayar menggunakan kredivo melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		UangMe 	
			
			Bayar pesanan dengan akun Uangme anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Credit Card (Xendit) 	
			
			Pay with your credit card via Xendit.TEST MODE. Try card &quot;4000000000000002&quot; with any CVN and future expiration date, or see Xendit Docs for more test cases.
		
	
		
		
		
			Since your browser does not support JavaScript, or it is disabled, please ensure you click the &lt;em>Update Totals&lt;/em> button before placing your order. You may be charged more than the amount stated above if you fail to do so.			&lt;br/>&lt;button type=&quot;submit&quot; class=&quot;button alt&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update totals&quot;>Update totals&lt;/button>
		

			
		
			
	
		Dengan menggunakan metode pembayaran ini, anda setuju bahwa semua data yang berhubungan dengan order anda akan diproses oleh saluran pembayaran.
		Place order
		
			


	

	



	
	


			' or . = '

				

	

    
        Checkout    


	
		
	
	
		Have a coupon? Click here to enter your code	




	If you have a coupon code, please apply it below.

	
		
	

	
		Apply coupon
	

	




	
		
		
			
				
	
		Billing details

	
	
	
			First name *Last name *Company name (optional)Country / Region *Select a country / region…AfghanistanÅland IslandsAlbaniaAlgeriaAmerican SamoaAndorraAngolaAnguillaAntarcticaAntigua and BarbudaArgentinaArmeniaArubaAustraliaAustriaAzerbaijanBahamasBahrainBangladeshBarbadosBelarusBelauBelgiumBelizeBeninBermudaBhutanBoliviaBonaire, Saint Eustatius and SabaBosnia and HerzegovinaBotswanaBouvet IslandBrazilBritish Indian Ocean TerritoryBruneiBulgariaBurkina FasoBurundiCambodiaCameroonCanadaCape VerdeCayman IslandsCentral African RepublicChadChileChinaChristmas IslandCocos (Keeling) IslandsColombiaComorosCongo (Brazzaville)Congo (Kinshasa)Cook IslandsCosta RicaCroatiaCubaCuraçaoCyprusCzech RepublicDenmarkDjiboutiDominicaDominican RepublicEcuadorEgyptEl SalvadorEquatorial GuineaEritreaEstoniaEswatiniEthiopiaFalkland IslandsFaroe IslandsFijiFinlandFranceFrench GuianaFrench PolynesiaFrench Southern TerritoriesGabonGambiaGeorgiaGermanyGhanaGibraltarGreeceGreenlandGrenadaGuadeloupeGuamGuatemalaGuernseyGuineaGuinea-BissauGuyanaHaitiHeard Island and McDonald IslandsHondurasHong KongHungaryIcelandIndiaIndonesiaIranIraqIrelandIsle of ManIsraelItalyIvory CoastJamaicaJapanJerseyJordanKazakhstanKenyaKiribatiKuwaitKyrgyzstanLaosLatviaLebanonLesothoLiberiaLibyaLiechtensteinLithuaniaLuxembourgMacaoMadagascarMalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritaniaMauritiusMayotteMexicoMicronesiaMoldovaMonacoMongoliaMontenegroMontserratMoroccoMozambiqueMyanmarNamibiaNauruNepalNetherlandsNew CaledoniaNew ZealandNicaraguaNigerNigeriaNiueNorfolk IslandNorth KoreaNorth MacedoniaNorthern Mariana IslandsNorwayOmanPakistanPalestinian TerritoryPanamaPapua New GuineaParaguayPeruPhilippinesPitcairnPolandPortugalPuerto RicoQatarReunionRomaniaRussiaRwandaSão Tomé and PríncipeSaint BarthélemySaint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (Dutch part)Saint Martin (French part)Saint Pierre and MiquelonSaint Vincent and the GrenadinesSamoaSan MarinoSaudi ArabiaSenegalSerbiaSeychellesSierra LeoneSingaporeSlovakiaSloveniaSolomon IslandsSomaliaSouth AfricaSouth Georgia/Sandwich IslandsSouth KoreaSouth SudanSpainSri LankaSudanSurinameSvalbard and Jan MayenSwedenSwitzerlandSyriaTaiwanTajikistanTanzaniaThailandTimor-LesteTogoTokelauTongaTrinidad and TobagoTunisiaTurkeyTurkmenistanTurks and Caicos IslandsTuvaluUgandaUkraineUnited Arab EmiratesUnited Kingdom (UK)United States (US)United States (US) Minor Outlying IslandsUruguayUzbekistanVanuatuVaticanVenezuelaVietnamVirgin Islands (British)Virgin Islands (US)Wallis and FutunaWestern SaharaYemenZambiaZimbabweIndonesia&lt;button type=&quot;submit&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update country / region&quot;>Update country / region&lt;/button>Street address *Apartment, suite, unit, etc. (optional)Town / City *Province *Select an option…Daerah Istimewa AcehSumatera UtaraSumatera BaratRiauKepulauan RiauJambiSumatera SelatanBangka BelitungBengkuluLampungDKI JakartaJawa BaratBantenJawa TengahJawa TimurDaerah Istimewa YogyakartaBaliNusa Tenggara BaratNusa Tenggara TimurKalimantan BaratKalimantan TengahKalimantan TimurKalimantan SelatanKalimantan UtaraSulawesi UtaraSulawesi TengahSulawesi TenggaraSulawesi BaratSulawesi SelatanGorontaloMalukuMaluku UtaraPapuaPapua BaratBantenPostcode / ZIP *Phone *Email address *

	

			

			
				
	

	
	
		
			Additional information

		
		
							Order notes (optional)					

	
	
			
		

		
		
		
	Your order
	
	
	
		
	
		
			Product
			Subtotal
		
	
	
						
					
						Album 						 × 1											
					
						Rp15.000					
				
								
					
						Beanie with Logo 						 × 1											
					
						Rp20.000					
				
								
					
						Cap 						 × 1											
					
						Rp16.000					
				
					
	

		
			Subtotal
			Rp51.000
		

		
		
		
		
		
		
			Total
			Rp51.000 
		

		
	



			
			
	

	
		Bank Transfer - BCA 	
			
			Bayar pesanan dengan transfer bank BCA dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BNI 	
			
			Bayar pesanan dengan transfer bank BNI dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BRI 	
			
			Bayar pesanan dengan transfer bank BRI dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BSI 	
			
			Bayar pesanan dengan transfer bank BSI dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - BJB 	
			
			Bayar pesanan dengan transfer bank BJB dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - Mandiri 	
			
			Bayar pesanan dengan transfer bank Mandiri dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bank Transfer - Permata 	
			
			Bayar pesanan dengan transfer bank Permata dengan virtual account melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bayar di Alfamart Group 	
			
			Bayar pesanan dengan membayar di Alfa group (Alfamart, Alfamidi &amp; Dan+Dan) melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Bayar di Indomaret 	
			
			Bayar pesanan dengan membayar di Indomaret, Indogrosir, Superindo, atau i.saku melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		ShopeePay 	
			
			Bayar pesanan dengan akun ShopeePay anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		OVO 	
			
			Bayar dengan OVO Anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		DANA 	
			
			Bayar dengan DANA Anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		LinkAja 	
			
			Bayar pesanan dengan akun LINKAJA anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Direct Debit BRI 	
			
			Bayar pesanan dengan akun Direct Debit BRI anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		QRIS 	
			
			Bayar pesanan dengan akun QRIS anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Kredivo 	
			
			Bayar pesanan dengan membayar menggunakan kredivo melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		UangMe 	
			
			Bayar pesanan dengan akun Uangme anda melalui Xendit
                TEST MODE - Real payment will not be detected		
	

	

	
		Credit Card (Xendit) 	
			
			Pay with your credit card via Xendit.TEST MODE. Try card &quot;4000000000000002&quot; with any CVN and future expiration date, or see Xendit Docs for more test cases.
		
	
		
		
		
			Since your browser does not support JavaScript, or it is disabled, please ensure you click the &lt;em>Update Totals&lt;/em> button before placing your order. You may be charged more than the amount stated above if you fail to do so.			&lt;br/>&lt;button type=&quot;submit&quot; class=&quot;button alt&quot; name=&quot;woocommerce_checkout_update_totals&quot; value=&quot;Update totals&quot;>Update totals&lt;/button>
		

			
		
			
	
		Dengan menggunakan metode pembayaran ini, anda setuju bahwa semua data yang berhubungan dengan order anda akan diproses oleh saluran pembayaran.
		Place order
		
			


	

	



	
	


			')]</value>
      <webElementGuid>42395912-5a1f-4f06-a717-a03e197f4b4c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
